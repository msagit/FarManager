Macro {
  description="Use Del to remove files";
  area="Shell Tree"; key="Del NumDel"; flags="EmptyCommandLine EnableOutput";
  action = function() Keys('F8') end;
}

Macro {
  description="Use Del to remove files";
  area="Search"; key="Del NumDel"; flags="EnableOutput";
  action = function() Keys('F8') end;
}
