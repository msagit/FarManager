Macro {
  area="Editor"; key="CtrlS"; description="Editor: Save File"; action = function()
Keys('F2')
  end;
}

