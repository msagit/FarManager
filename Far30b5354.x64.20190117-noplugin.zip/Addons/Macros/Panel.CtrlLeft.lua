Macro {
  area="Shell"; key="CtrlLeft"; flags="EmptyCommandLine"; description="Use Ctrl-Left to change current drive to the previous"; action = function()
Keys('F9 Enter Up Enter Up Enter Esc')
  end;
}

