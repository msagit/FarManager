Macro {
  area="Editor"; key="CtrlW"; description="Editor: Save File and Exit"; action = function()
Keys('ShiftF10')
  end;
}

