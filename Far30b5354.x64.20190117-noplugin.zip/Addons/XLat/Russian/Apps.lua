Macro {
  area="Common"; key="Apps"; description="Use hotkey <Apps> to perform XLat function."; flags=""; action = function()
Keys('xlat')
  end;
}

