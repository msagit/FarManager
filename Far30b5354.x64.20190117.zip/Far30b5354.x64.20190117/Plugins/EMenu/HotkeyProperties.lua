Macro {
  area="Shell"; key="CtrlAltEnter"; flags=""; description="Hotkey to execute properties command: Ctrl-Alt-Enter"; action = function()
Keys("Esc") Far.DisableHistory(0) print("rclk_cmd:properties") Keys("Enter")
  end;
}

Macro {
  area="Tree"; key="CtrlAltEnter"; flags=""; description="Hotkey to execute properties command: Ctrl-Alt-Enter"; action = function()
Keys("Esc") Far.DisableHistory(0) print("rclk_cmd:properties") Keys("Enter")
  end;
}

