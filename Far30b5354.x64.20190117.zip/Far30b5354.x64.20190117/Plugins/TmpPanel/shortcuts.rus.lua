Macro {
  area="Shell"; key="CtrlApps"; flags=""; action = function()
 Keys("t m p : + m e n u Space s h o r t c u t s . r u s . t e m p Enter") 
  end;
}

