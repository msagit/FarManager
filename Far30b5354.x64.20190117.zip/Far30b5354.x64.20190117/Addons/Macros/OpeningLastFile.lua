Macro {
  area="Shell Viewer Editor"; key="Ctrl'"; description="Opening last view/edit of a file"; action = function()
Keys('AltF11 Up Enter')
  end;
}
