Macro {
  area="Search"; key="CtrlIns CtrlShiftIns CtrlALtIns CtrlNum0 CtrlShiftNum0 CtrlALtNum0";
  description="CtrlIns in fast search"; action = function()
    Keys('Esc AKey')
  end;
}
