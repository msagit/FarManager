Macro {
  area="Viewer"; key="Add"; description="Move to next file and update panel position"; action = function()
Keys('Add CtrlF10 Shift')
  end;
}

Macro {
  area="Viewer"; key="Subtract"; description="Move to previous file and update panel position"; action = function()
Keys('Subtract CtrlF10 Shift')
  end;
}

